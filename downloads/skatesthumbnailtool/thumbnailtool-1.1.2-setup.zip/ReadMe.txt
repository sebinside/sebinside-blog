skate's Thumbnail Tool
README Datei

---------------------------------------------------

---------------------------------------
1. Probleme mit dem VisioPlayer
---------------------------------------

Sollte es Probleme mit dem VisioPlayer geben, kannst du diese eventuell beheben, 
indem du die VisioPlayer SDK installierst und den PC danach neu startest!

Die kostenlose SDK-Installationsdatei liegt diesem Pack bei. Diese darf nach den Lizenzbestimmungen mitverbreitet werden:

"You may share the unregistered Software with other people only if the Software is distributed in this original setup package."
Das Original Setup Packet liegt bei.

Siehe: http://www.visioforge.com/Licenses/media-player-sdk-license-agreement-without-source-code.html